
this is stable. its code was ripped from IDA_JScript
where it was first developed. now its in an easy to use package.

IDA_Compare makes use of this library, as does OllySyncBridge

It has no external dependancies.
